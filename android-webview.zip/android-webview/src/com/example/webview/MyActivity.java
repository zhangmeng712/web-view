package com.example.webview;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    public void onClick_Event(View view) {
        EditText et = (EditText) findViewById(R.id.url);
        String url = String.valueOf(et.getText());
        Intent intent = new Intent();
        intent.setClass(MyActivity.this, WebActivity.class);
        intent.putExtra("url", url.trim());
        startActivity(intent);
    }
}
