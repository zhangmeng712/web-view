package com.example.webview;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Created by lilong on 14-3-4.
 *
 */
public class WebActivity extends Activity {

    WebView webview;

    public void onCreate(Bundle savedInstanceState) {
        Log.d("start", "start");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.web);
        Intent intent = getIntent();
        String url = intent.getStringExtra("url");
        if (url == null || url.trim().isEmpty()) {
            return;
        } else {
            Log.d("start", "start1");
            webview = (WebView) findViewById(R.id.webview);//与xml中元素的@+id/webview 对应
            webview.getSettings().setJavaScriptEnabled(true);
            webview.setWebViewClient(new HelloWebViewClient());
            webview.loadUrl(url.trim());
//            webview.loadUrl("http://10.32.228.35/mbp/");
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webview.canGoBack()) {
            webview.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    class HelloWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }
}