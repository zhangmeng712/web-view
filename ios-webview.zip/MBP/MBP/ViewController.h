//
//  ViewController.h
//  MBP
//
//  Created by zhangmeng on 13-12-12.
//  Copyright (c) 2013年 zhangmeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{  
    UIWebView *webView;
}
@end
